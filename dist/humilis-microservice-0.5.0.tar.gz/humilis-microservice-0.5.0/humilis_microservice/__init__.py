"""Humilis plug-in to deploy a Lambda microservice"""


__version__ = "0.5.0"
__author__ = "German Gomez-Herrero, FindHotel BV"
